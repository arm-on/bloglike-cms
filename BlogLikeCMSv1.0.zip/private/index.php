<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>BL ADMIN</title>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet/less" href="less/styles.less" type="text/css">
        <script src="js/less.min.js"></script>
        <?php include_once("framework.php");?>
            <?php BL_CKEDITOR_HEAD();?>
    </head>
    <body>
        <?php
            session_start();
            //$_SESSION['logged_user']="admin";
            ?>
        <div class="topmenu">
            <div class="col-sm-10">
                  <input type="text" class="form-control search" id="usr">
            </div>
            <div class="col-sm-2">
                <img class="img-responsive icon-menu" src="img/icon/menu.png">
                <h4>پنل مدیریت</h4>
            </div>
        </div>
        <div class="main">
            <div class="col-sm-10 boxes">

            
                
                <div class="col-sm-4"></div>
                <div class="col-sm-4 box-left">
                    <div class="row">
                        <div class="box-top">
                            <div class="box-top">
                                <div class="navigate" style="background-position: 98%">دسترسی سریع</div>
                            </div>
                        </div>
                    </div>
                    <div class="row"><div class="box-bottom" style="height:310px">
                        <a href="posts.bl?do=new" class="btn btn-primary" style="float:right;margin-right:5px;margin-top:5px;width:200px">ایجاد مطلب جدید</a><br><br>
                        <a href="pages.bl?do=new" class="btn btn-success" style="float:right;margin-right:5px;margin-top:5px;width:200px">ایجاد صفحه جدید</a><br><br>
                        <a href="menus.bl" class="btn btn-warning" style="float:right;margin-right:5px;margin-top:5px;width:200px">منو ها</a><br><br>
                        <a href="uploader.bl" class="btn btn-danger" style="float:right;margin-right:5px;margin-top:5px;width:200px">آپلود ها</a><br><br>
    
                    </div></div>
                </div>
                
                
                
                
                
                <div class="col-sm-4 box-right">
                    <div class="row">
                        <div class="box-top">
                            <div class="overview" style="background-position: 98.5%;">وضعیت کلی سایت</div>
                        </div>
                    </div>
                    <div class="row"><div class="box-bottom" style="height:310px;">
                           <div class="table-responsive" style="direction: rtl;float:right">          
                            <table class="table">
                              <tbody>
                                <tr>
                                  <td><img class="img-responsive dash-img" src="img/icon/postcount.png"></td>
                                  <td><h4 class="txt">تعداد مطالب : <?php BL_POST_COUNT("echo")?></h4></td>
                                </tr>
                                <tr>
                                  <td><img class="img-responsive dash-img" src="img/icon/catcount.png"></td>
                                  <td><h4 class="txt">تعداد موضوعات : <?php echo BL_CAT_COUNT()?></h4></td>
                                </tr>
                                <tr>
                                  <td><img class="img-responsive dash-img" src="img/icon/pages.png"></td>
                                  <td><h4 class="txt">تعداد صفحات : <?php echo BL_PAGE_COUNT()?></h4></td>
                                </tr>
                                <tr>
                                  <td><img class="img-responsive dash-img" src="img/icon/usercount.png"></td>
                                  <td><h4 class="txt">تعداد کاربران : <?php echo BL_USER_COUNT()?></h4></td>
                                </tr>
                                <tr>
                                  <td><img class="img-responsive dash-img" src="img/icon/tablet.png"></td>
                                  <td><h4 class="txt">تعداد منو ها : <?php echo BL_MOI_COUNT()?></h4></td>
                                </tr>
                              </tbody>
                            </table>
                           </div>
                    </div></div>
                </div>
                
  
            </div>
            <div class="col-sm-2 items">
                <div class="row">
                    <?php include("sidebar.php");?>
                </div>
                
            </div>
        </div>
    </body>
</html>